import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { FaEdit, FaTrash, FaPlus } from "react-icons/fa";

const ProductsManagement = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  const fetchProducts = async () => {
    setLoading(true);
    try {
      const res = await axios.get(`${import.meta.env.VITE_API_URL}/inventory`);
      setProducts(res.data.data || []);
    } catch (err) {
      console.error("Failed to fetch products:", err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const handleDelete = async (id) => {
    if (confirm("Are you sure you want to delete this product?")) {
      try {
        await axios.delete(`${import.meta.env.VITE_API_URL}/inventory/${id}`);
        setProducts((prev) => prev.filter((p) => p._id !== id));
      } catch (err) {
        console.error("Delete failed:", err.message);
      }
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Manage Products</h1>
        <button
          onClick={() => navigate("/admin/products/add")}
          className="flex items-center gap-2 bg-[#A58077] text-white px-4 py-2 rounded-lg hover:bg-[#E5CBBE] hover:text-[#181818] transition"
        >
          <FaPlus />
          Add Product
        </button>
      </div>

      {/* Products Table */}
      {loading ? (
        <div className="grid md:grid-cols-3 gap-6 animate-pulse">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="h-32 bg-[#2c2c2c] rounded-lg" />
          ))}
        </div>
      ) : products.length === 0 ? (
        <p className="text-[#A58077] text-center">No products found.</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map((product) => (
            <div
              key={product._id}
              className="bg-[#2c2c2c] p-4 rounded-lg flex flex-col items-center shadow-md"
            >
              <img
                src={product.filePath}
                alt={product.name}
                className="h-40 w-full object-cover rounded-md mb-4"
              />
              <h3 className="text-lg font-bold">{product.name}</h3>
              <p className="text-sm text-[#A58077]">${product.price}</p>

              <div className="flex gap-4 mt-4">
                <button
                  onClick={() => navigate(`/admin/products/edit/${product._id}`)}
                  className="text-[#E5CBBE] hover:text-[#A58077] transition"
                  title="Edit"
                >
                  <FaEdit size={18} />
                </button>
                <button
                  onClick={() => handleDelete(product._id)}
                  className="text-red-500 hover:text-red-700 transition"
                  title="Delete"
                >
                  <FaTrash size={18} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ProductsManagement;

import { useEffect, useState } from "react";

const Dashboard = () => {
  const [stats, setStats] = useState(null);

  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setStats({
        users: 120,
        products: 58,
        sales: 7560,
      });
    }, 1000);
  }, []);

  if (!stats) {
    return (
      <div className="grid md:grid-cols-3 gap-6 animate-pulse">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="h-32 bg-[#2c2c2c] rounded-lg" />
        ))}
      </div>
    );
  }

  return (
    <div className="grid md:grid-cols-3 gap-6">
      <Card title="Total Users" value={stats.users} />
      <Card title="Total Products" value={stats.products} />
      <Card title="Total Sales" value={`$${stats.sales}`} />
    </div>
  );
};

const Card = ({ title, value }) => (
  <div className="bg-[#2c2c2c] p-6 rounded-lg flex flex-col justify-center items-center shadow-md">
    <h3 className="text-lg font-semibold mb-2">{title}</h3>
    <div className="text-3xl font-bold">{value}</div>
  </div>
);

export default Dashboard;

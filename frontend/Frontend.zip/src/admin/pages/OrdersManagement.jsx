// src/admin/pages/AdminOrders.jsx
import { useEffect, useState } from "react";
import axios from "axios";
import Loader from "../../components/Loader";
import { toast } from "react-toastify";
import { FiTruck, FiCheckCircle } from "react-icons/fi";

const AdminOrders = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchOrders = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem("authToken");
      const response = await axios.get(`${import.meta.env.VITE_API_URL}/admin/orders`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setOrders(response.data.data || []);
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed to fetch orders.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  const handleMarkAsDelivered = async (orderId) => {
    try {
      const token = localStorage.getItem("authToken");
      await axios.put(`${import.meta.env.VITE_API_URL}/admin/orders/${orderId}/deliver`, {}, {
        headers: { Authorization: `Bearer ${token}` },
      });
      toast.success("Order marked as delivered!");
      fetchOrders(); // Refresh list
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed to update order status.");
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader size={60} />
      </div>
    );
  }

  return (
    <div className="p-6">
      <h1 className="text-4xl font-bold mb-8">Manage Orders</h1>

      {orders.length === 0 ? (
        <div className="text-center text-[#A58077]">No orders found yet.</div>
      ) : (
        <div className="overflow-x-auto rounded-lg shadow-md bg-[#2c2c2c] text-[#E5CBBE]">
          <table className="min-w-full text-sm">
            <thead>
              <tr className="bg-[#A58077] text-[#181818]">
                <th className="px-6 py-3 text-left font-semibold">Order ID</th>
                <th className="px-6 py-3 text-left font-semibold">Customer</th>
                <th className="px-6 py-3 text-left font-semibold">Total</th>
                <th className="px-6 py-3 text-left font-semibold">Status</th>
                <th className="px-6 py-3 text-left font-semibold">Actions</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((order) => (
                <tr key={order._id} className="border-b border-[#A58077]/20">
                  <td className="px-6 py-4">{order._id.slice(-6).toUpperCase()}</td>
                  <td className="px-6 py-4">{order.customerName}</td>
                  <td className="px-6 py-4">${order.totalPrice.toFixed(2)}</td>
                  <td className="px-6 py-4">
                    {order.isDelivered ? (
                      <span className="text-green-400">Delivered</span>
                    ) : (
                      <span className="text-yellow-400">Pending</span>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    {!order.isDelivered && (
                      <button
                        onClick={() => handleMarkAsDelivered(order._id)}
                        className="flex items-center gap-2 bg-[#A58077] text-white px-3 py-2 rounded-md hover:bg-[#E5CBBE] hover:text-[#181818] transition"
                      >
                        <FiTruck />
                        Mark Delivered
                      </button>
                    )}
                    {order.isDelivered && (
                      <span className="flex items-center gap-2 text-green-400">
                        <FiCheckCircle />
                        Completed
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default AdminOrders;
